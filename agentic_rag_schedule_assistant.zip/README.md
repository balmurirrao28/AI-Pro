# Agentic RAG Schedule Assistant

A deployable FastAPI Agentic RAG schedule assistant for a 30-day schedule.

## Features
- ChromaDB vector store
- RAG retrieval through `get_schedule`
- Agentic mutation through `update_schedule`
- Add, update/move, and remove events
- Sample meetings, workshops, tasks, and appointments
- FastAPI API plus browser UI
- Render-ready single `app.py`

## Run locally

```bash
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000`.

## Render deployment

Create a new Render Web Service from this repository.

Build Command:
```bash
pip install -r requirements.txt
```

Start Command:
```bash
uvicorn app:app --host 0.0.0.0 --port $PORT
```

No `.env` or YAML file is required.

## API

POST `/chat`

```json
{"message":"What do I have scheduled tomorrow?"}
```

The response includes the selected tool and returned schedule data.

GET `/health` checks deployment status.

## Schedule window

The sample schedule covers August 12, 2026 through September 10, 2026.
